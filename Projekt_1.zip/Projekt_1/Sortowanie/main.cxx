#include <iostream>
#include <fstream>
#include <vector>
#include "Timer.h"
#include "Tester.h"
#include "quick_sort.h"
#include "heap_sort.h"
#include "insertion_sort.h"

template<typename Type>
std::ostream& operator << (std::ostream& output, std::vector<Type> input)
{
	for(unsigned int i = 0; i < input.size(); i++)
	{
		output << input[i] << " ";
	}
	return output;
}

template<typename Type>
std::istream& operator >> (std::istream& output, std::vector<Type>& input)
{
	for(unsigned int i = 0; i < input.size(); i++)
	{
		output >> input[i];
	}
	return output;
}

template<typename Type>
std::vector<Type> reverse(const std::vector<Type>& input)
{
	std::vector<Type> output(input.size());
	for(unsigned int i = 0; i < input.size(); i++)
	{
		output[i] = input[input.size()-1-i];
	}
	return output;
}

template<typename Type>
class SortTester : public Tester<std::vector<Type>, std::vector<Type>>
{
	protected:
		std::vector<Type> readInput(std::istream& input) override
		{
			unsigned int Size = 0;
			input >> Size;
			std::vector<Type> data(Size);
			input >> data;
			return data;
		}
		std::vector<Type> runAlgorithm(const std::vector<Type>& data) override
		{
			std::vector<Type> output = data;
			if(command == "QS")
			{
				sortingq<Type> temp;
				temp.quick_sort(output);
			}
			else if(command == "HS")
			{
				sortingh<Type>(output);
			}
			else if(command == "IS")
			{
				sortingi<Type> temp(output);
			}
			return output;
		}
	public:
		SortTester(std::string cmd)
		{
			command = cmd;
		}
		std::string command;
};

int main()
{
	std::string command;
	
	std::cout << std::endl << "Wprowad� plik wej�ciowy" << std::endl;
	std::cin >> command;
	std::ifstream input;
	input.open(command.c_str());
	if(input.is_open() == false) { std::cout << std::endl << "Nie mo�na odtworzy� plik" << std::endl; return 2; }
		
	std::cout << std::endl << "Wprowad� plik wyj�ciowy" << std::endl;
	std::cin >> command;
	std::ofstream output;
	output.open(command.c_str());
		
	std::cout << std::endl << "Wprowad�:" << std::endl;
	std::cout << "QS - Szybkie sortowanie" << std::endl;
	std::cout << "HS - Sortowanie przez kopcowanie" << std::endl;
	std::cout << "IS - Sortowanie przez wstawianie" << std::endl;
	std::cin >> command;
		
	SortTester<int> tester(command);
	tester.runTests(input,output);
	return 0;
}

