#ifndef introspective_sort_h
#define introspective_sort_h

#include<iostream>
#define _USE_MATH_DEFINES
#include<cmath>
#include<vector>
using namespace std;
   
template < typename T >
class sortingi
{
	private:
		void IntrospectiveSort(T *Tab, int length)
		{
		  IntroSort(Tab,length,(int)floor(2*log(length)/log(2)));
		  Insertion_Sort(Tab,length);
		}
		void IntroSort (T *Tab, int length, int M)
		{
		  int i;

		  if (M<=0)
		  {
			Heap_Sort(Tab,length);
			return;
		  }

		  i = Partition(Tab,0,length);

		  if (i>9)
			IntroSort(Tab,i,M-1);

		  if (length-1-i>9)
			IntroSort(Tab+i+1,length-1-i,M-1);

		  }
		void Insertion_Sort (T *Tab, int length)
		{
		  int i, j;
		  T temp;
		  
		  for (i=1; i<length; ++i)
		  {
			temp=Tab[i];

			for (j=i; j>0 && temp<Tab[j-1]; --j)
			  Tab[j]=Tab[j-1];

			Tab[j]=temp;
		  }

		}
		int Partition (T *Tab, int left , int right)
		{
		  int i, j;

		  if (right>=3)
			MedianOfThree(Tab,left,right);
			
		  for (i=left , j=right-2; ; )
		  {
			for ( ; Tab[i]<Tab[right-1]; ++i);
			for ( ; j>=left  && Tab[j]>Tab[right-1]; --j);
			if (i<j) swap(Tab[i++],Tab[j--]);
			else break;
		  }

		  swap(Tab[i],Tab[right-1]);
		  return i;
		}
		void MedianOfThree (T *Tab, int &left, int &right)
		{
		  if (Tab[++left-1]>Tab[--right])
			swap(Tab[left-1],Tab[right]);

		  if (Tab[left-1]>Tab[right/2])
			swap(Tab[left-1],Tab[right/2]);

		  if (Tab[right/2]>Tab[right])
			swap(Tab[right/2],Tab[right]);

		  swap(Tab[right/2],Tab[right-1]);
		}
		inline void swap (T& a, T& b)
		{
		  T temp = a;
		  a = b;
		  b = temp;
		}
		void Heap_Sort (T *Tab, int length)
		{
		  int parent;

		  for (parent=length/2; parent>0; --parent)
			Heapify(Tab-1,parent,length);

		  for (parent=length-1; parent>0; --parent)
		  {
			swap(Tab[0],Tab[parent]);
			Heapify(Tab-1,1,parent);
		  }

		}
		void Heapify (T *Tab, int parent, int length)
		{
		  int child;

		  while (parent<=length/2)
		  {
			child=2*parent;

			if (child+1<=length && Tab[child+1]>Tab[child])
			  child=child+1;

			if (Tab[parent]<Tab[child])
			  swap(Tab[parent],Tab[child]);

			else break;
			  parent=child;
			}
		  }
	protected:
		std::vector<T>& ref;
	public:
		sortingi(std::vector<T>& to_sort) : ref(to_sort)
		{
			T* Tab;
			Tab = new T[ref.size()];
			for(unsigned int i = 0; i < ref.size(); i++)
			{
				Tab[i] = ref[i];
			}
			IntrospectiveSort(Tab,ref.size());
			for(unsigned int i = 0; i < ref.size(); i++)
			{
				ref[i] = Tab[i];
			}
			delete Tab;
		}
};

#endif
