#ifndef quick_sort_h
#define quick_sort_h

#include<iostream>
using namespace std;

template<typename t>
class sortingq {
public:
	std::vector<t> quick_sort(std::vector<t>& input)
	{
		workspace_quick_sort(0, input.size() - 1, input);
		return input;
	}
private:
	void workspace_quick_sort(const unsigned int& left, const unsigned int& right, std::vector<t>& input)
	{
		if (left < right)
		{
			unsigned int q = workspace_patrition(left, right, input);
			workspace_quick_sort(left, q, input);
			workspace_quick_sort(q+1, right, input);
		}
	}
	unsigned int workspace_patrition(const unsigned int& left, const unsigned int& right, std::vector<t>& input)
	{
		t reference_point = input[(left + right) / 2];
		unsigned int l = left, r = right;
		while (true)
		{
			while (input[l] < reference_point)
			{
				l++;
			}
			while (input[r] > reference_point)
			{
				r--;
			}
			if (l < r)
			{
				t temp = input[l];
				input[l] = input[r];
				input[r] = temp;
				l++;
				r--;
			}
			else
			{
				return r;
			}
		}
	}
}; 
#endif /* quick_sort_h */
