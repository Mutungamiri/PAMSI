#ifndef merge_sort_hh
#define merge_sort_hh

#include <vector>

template < typename T >
class sortingm
{
	protected:
		std::vector<T>& ref;
		std::vector<T> copy;
	public:
		sortingm(std::vector<T>& to_sort) : ref(to_sort)
		{
			copy = to_sort;
			workspace_merge_sort(0,ref.size()-1);
		}
	private: 
		inline void workspace_merge_sort(const unsigned int& left, const unsigned int& right)
		{
			if(left >= right) return;
			unsigned int mid = (left+right)/2;
			workspace_merge_sort(left,mid);
			workspace_merge_sort(mid+1,right);
			workspace_merge(left,right,mid);
		}
		inline void workspace_merge(const unsigned int& left, const unsigned int& right, const unsigned int& mid)
		{
			for(unsigned int i = left; i <= right; i++)
			{
				copy[i] = ref[i];
			}
			unsigned int i = left, j = mid + 1;
			for(unsigned k = left; k <= right; k++)
			{
				if(i<=mid)
				{
					if(j<=right)
					{
							if(copy[j]<copy[i])
							{
								ref[k] = copy[j++];
							}
							else
							{
								ref[k] = copy[i++];
							}
					}
					else
					{
						ref[k] = copy[i++];
					}
				}
				else
				{
					ref[k] = copy[j++];
				}
			}
		}
};

#endif 
