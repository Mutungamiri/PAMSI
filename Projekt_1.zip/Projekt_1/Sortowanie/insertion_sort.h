#ifndef insertion_sort_h
#define insertion_sort_h


/* Insertion Sort using Template */
#include<iostream>
using namespace std;

template<class t>
class sortingi {
public:
	sortingi(std::vector<t>& list ) {

		/* Sorting data using insertion sort algorithm */
		for (int i = 1; i < int(list.size()); i++) {
			for (int j = i; j > 0; j--) {
				if (list[j] < list[j - 1]) {
					t temp = list[j - 1];
					list[j - 1] = list[j];
					list[j] = temp;
				}
			}
		}
	}
}; 
#endif /* insertion_sort_h */
