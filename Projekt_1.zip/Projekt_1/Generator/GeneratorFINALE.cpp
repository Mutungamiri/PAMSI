#include <iostream>
#include <fstream>
#include <ctime>
#include <cstdlib>
#include <string>
#include <vector>

/* ************************************************************************************ */

template<typename Type>
class Array
{
	public:
		inline void swap(Type& a, Type& b) const { Type c = a; a = b; b = c; }
		void workspace_quick_sort(const unsigned int& left, const unsigned int& right);
		unsigned int workspace_partition(const unsigned int& left, const unsigned int& right);
	public:
		std::vector<Type> values;
	public:
		unsigned int size(void) const { return values.size(); }
		Type& operator [] (const unsigned int& index)       { return values[index]; }
		Type  operator [] (const unsigned int& index) const { return values[index]; }
		Array(unsigned int Size) : values(Size) {}
		
		Array<Type> sort_quick(void) const;
		Array<Type> reverse(void) const;
		
		Array(const Array<Type>&& temp) { this->values = temp.values; }
		Array(const Array<Type>& temp) { this->values = temp.values; }
		Array<Type>& operator = (const Array<Type>& temp) { values = temp.values; return *this; }
};

template<typename Type>
std::istream& operator >> (std::istream& input, Array<Type>& array)
{
	for(unsigned int i = 0; i < array.size(); i++)
	{
		input >> array[i];
	}
	return input;
}

template<typename Type>
std::ostream& operator << (std::ostream& output, Array<Type> array)
{
	for(unsigned int i = 0; i < array.size(); i++)
	{
		output << array[i] << " ";
	}
	return output;
}

template<typename Type>
Array<Type> Array<Type>::reverse(void) const
{
	const unsigned int Size = this->size();
	Array<Type> output(Size);
	for(unsigned int i = 0; i < Size; i++)
	{
		output[i] = (*this)[Size-1-i];
	}  
	return output;
}

template<typename Type>
Array<Type> Array<Type>::sort_quick(void) const
{
	Array<Type> output = *this;
	output.workspace_quick_sort(0,size()-1);
	return output;
}

template<typename Type>
void Array<Type>::workspace_quick_sort(const unsigned int& left, const unsigned int& right)
{
	if(left < right)
	{
		unsigned int q = this->workspace_partition(left,right);
		this->workspace_quick_sort(left,q);
		this->workspace_quick_sort(q+1,right);
	}
}

template<typename Type>
unsigned int Array<Type>::workspace_partition(const unsigned int& left, const unsigned int& right)
{
	Type reference_point = (*this)[(left+right)/2];
	unsigned int l = left, r = right;
	while(true)
	{
		while((*this)[r] > reference_point)
		{
			r--;
			if(r<=left) break;
		}
		while((*this)[l] < reference_point)
		{
			l++;
			if(l>=right) break;
		}
		if(l < r)
		{
			swap((*this)[l],(*this)[r]);
			l++;
			r--;
		}
		else
		{
			return r;
		}
	}
}

struct SetInformation
{
	unsigned int Size;
	int min;
	int max;
	unsigned int sortedPercentage;
	unsigned int times;
};

std::ostream& operator << (std::ostream& stream, SetInformation info)
{
	stream << "Rozmiar: " << info.Size << " Ile razy: " << info.times << " Procent: " << info.sortedPercentage;
	return stream;
}

std::ostream& operator << (std::ostream& stream, std::vector<int> vector)
{
	stream << vector.size() << " ";
	for(unsigned int i = 0; i < vector.size(); i++)
	{
		stream << vector[i] << " ";
	}
	return stream;
}

inline int Loss(const int& min, const int& max)
{
	return ((rand()%(max-min+1))+min);
}

std::vector<int> GenerateNumberSet(SetInformation temp)
{
	std::vector<int> output(temp.Size);
	for(unsigned int i = 0; i < temp.Size; i++)
	{
		output[i] = Loss(temp.min,temp.max);
	}
	if(temp.sortedPercentage!=0)
	{
		Array<int> to_sort(output.size());
		to_sort.values = output;
		int max = (temp.sortedPercentage * output.size()) /100;
		to_sort.workspace_quick_sort(0,max);
		output = to_sort.values;
	}
	return output;
}

void SaveSet(std::ostream& output, const std::vector<int>& temp)
{
	output << temp.size() << " ";
	for(unsigned int j = 0; j < temp.size(); j++)
	{
		output << temp[j] << " ";
	}
	output << std::endl;
}

void SaveAllSets(std::ostream& output, std::vector<SetInformation> temp)
{
	for(unsigned int i = 0; i < temp.size(); i++)
	{
		for(unsigned int j = 0; j < temp[i].times; j++)
		{
			std::cout << "Generowanie: " << "Zestawu danych " << i << " Rozmiar " << temp[i].Size << " Procent: " << temp[i].sortedPercentage << std::endl;
			std::vector<int> tmp = GenerateNumberSet(temp[i]);
			std::cout << "Zapisywanie..." << std::endl;
			SaveSet(output,tmp);
		}
	}
}

int main(int argc, char **argv)
{
	srand(time(NULL));
	std::vector<SetInformation> informations;
	
	std::cout << std::endl << "Wprowad� nazwe pliku zapisu " << std::endl;
	std::string filename;
	std::cin >> filename;
	std::cout << std::endl;
	std::ofstream wyjscie;
	wyjscie.open(filename);
	if(!wyjscie.is_open()) { std::cerr << "B��d otworzenia pliku" << std::endl; return -1; }
	while(true)
	{
		std::cout << std::endl << "Generator tablic " << std::endl;
		std::cout << "Aby zako�czy� wpisz dowolny znak opr�cz liczby typu int" << std::endl;
		std::cout << "Obecnie" << std::endl;
		for(unsigned int i = 0; i < informations.size(); i++)
		{
			std::cout << informations[i] << std::endl;
		}
		SetInformation temp;
		std::cout << "Podaj rozmiar " << std::endl;
		std::cin >> temp.Size;
		//std::cout << std::endl << "Please type in min and max " << std::endl;
		//std::cin >> temp.min >> temp.max;
		temp.min = 1;
		temp.max = 9;
		//std::cout << std::endl << "Please type in times " << std::endl;
		//std::cin >> temp.times;
		temp.times = 100;
		std::cout << std::endl << "Podaj procent posortowania " << std::endl;
		std::cin >> temp.sortedPercentage;
		if(!std::cin.good())
		{
			break;
		}
		informations.push_back(temp);
	}
	
	SaveAllSets(wyjscie, informations);
	std::cout << "Generowanie zako�czone" << std::endl;
	return 0;
}
